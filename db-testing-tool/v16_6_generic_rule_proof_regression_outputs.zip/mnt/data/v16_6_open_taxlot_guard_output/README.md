# v16.6 Fast Generic Rule Proof Report

```json
{
  "version": "16.6-fast-generic-rule-proof",
  "profile": "taxlot",
  "mapping_rows": 66,
  "selected_resolved_columns": 4,
  "original_final_columns": 66,
  "fixed_final_columns": 66,
  "original_v15_class_counts": {
    "IN_BOTH_NO_REVIEW": 41,
    "REVIEW_REQUIRED": 4,
    "MATCH_EQUIVALENT": 21
  },
  "fixed_v15_class_counts": {
    "IN_BOTH_NO_REVIEW": 41,
    "REVIEW_REQUIRED": 4,
    "MATCH_EQUIVALENT": 21
  },
  "xml_column_delta_counts_selected": {
    "UNCHANGED": 4
  },
  "sql_block_delta_counts": {
    "UNCHANGED": 4
  },
  "delta_status_counts_v16_6": {
    "UNCHANGED": 62,
    "STILL_OPEN": 4
  },
  "fixed_by_resolved_rule_proof_v16_6": [],
  "fix_candidate_upstream_changed_v16_6": [],
  "still_open_v16_6": [
    "ACG_TP_NM",
    "MISS_COST_BSS_F",
    "MISS_IVS_COST_F",
    "WASH_SALE_TP"
  ],
  "new_regression_v16_6": []
}
```
