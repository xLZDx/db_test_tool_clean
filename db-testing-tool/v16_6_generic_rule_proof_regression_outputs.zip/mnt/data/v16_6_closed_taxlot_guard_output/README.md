# v16.6 Fast Generic Rule Proof Report

```json
{
  "version": "16.6-fast-generic-rule-proof",
  "profile": "taxlot",
  "mapping_rows": 84,
  "selected_resolved_columns": 5,
  "original_final_columns": 83,
  "fixed_final_columns": 83,
  "original_v15_class_counts": {
    "IN_BOTH_NO_REVIEW": 61,
    "REVIEW_REQUIRED": 5,
    "MATCH_EQUIVALENT": 18
  },
  "fixed_v15_class_counts": {
    "IN_BOTH_NO_REVIEW": 61,
    "REVIEW_REQUIRED": 5,
    "MATCH_EQUIVALENT": 18
  },
  "xml_column_delta_counts_selected": {
    "UNCHANGED": 4,
    "NO_RESOLVED_LINEAGE": 1
  },
  "sql_block_delta_counts": {
    "UNCHANGED": 7
  },
  "delta_status_counts_v16_6": {
    "UNCHANGED": 79,
    "STILL_OPEN": 5
  },
  "fixed_by_resolved_rule_proof_v16_6": [],
  "fix_candidate_upstream_changed_v16_6": [],
  "still_open_v16_6": [
    "ACG_TP_NM",
    "CCAL_PD_ID",
    "POS_CLS_CD",
    "SRC_STM_CD",
    "SRC_STM_NM"
  ],
  "new_regression_v16_6": []
}
```
