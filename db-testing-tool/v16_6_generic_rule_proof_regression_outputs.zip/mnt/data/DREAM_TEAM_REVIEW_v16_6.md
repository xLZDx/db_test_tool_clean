# Dream Team Review — v16.6 Generic Rule Proof

## Architect
The v16.6 proof layer removes the v16.5 hardcoded evidence boosters. The proof uses DRD-derived requirements and local target/resolved XML evidence. The v15/v16.4 delta-safe baseline remains the mismatch contract, but proof promotion is now generic.

## Data Engineer
Evidence terms are derived from current input values: DRD target column, DRD source columns, DRD rule, resolved ODI expression, and lineage path. There are no column-family branches such as SDIRA or DB_CARD in the proof layer.

## QA
Regression matrix passed:
- AVY: same five fields promoted to fixed as v16.5; no new regressions.
- Closed TaxLot: expected five still-open fields remain; no new regressions.
- Open TaxLot: expected four still-open fields remain; no new regressions.

## Risk Reviewer
The proof requires fixed XML to pass DRD-derived checks while original resolved lineage does not. Source guards use direct predicates (identifier=value or identifier IN (...value...)) to avoid false positives from unrelated numeric values.

## Performance
The resolver now resolves only relevant v15-open/changed columns, not every final column. AVY completed in ~21 seconds; each TaxLot guard completed in ~4 seconds.

## Verdict
Accept v16.6 as the generic rule-proof version. Keep v16.5 only as a diagnostic prototype.
