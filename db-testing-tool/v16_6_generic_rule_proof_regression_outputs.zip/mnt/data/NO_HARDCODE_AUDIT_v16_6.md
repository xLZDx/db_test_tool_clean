# v16.6 No-Hardcode Audit

Scope checked:
- reclassify_v16_6_generic_rule_proof.py
- compare_drd_odi_v16_6_generic_rule_proof.py
- compare_drd_odi_v16_6_fast_generic_rule_proof.py

Forbidden fixture-token grep:

```text
NO MATCHES
```

Result: the v16.6 proof layer has no hardcoded SDIRA/DB_CARD/CL_VAL_SDIRA/TRD_NUM boosters.

Note: compare_drd_odi_universal.py is the legacy v15 baseline module and still contains its existing profiles/curated findings. v16.6 proof promotion is independent from those hardcoded boosters.
