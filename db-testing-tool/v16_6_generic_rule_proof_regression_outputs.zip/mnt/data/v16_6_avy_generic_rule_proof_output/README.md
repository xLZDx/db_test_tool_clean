# v16.6 Fast Generic Rule Proof Report

```json
{
  "version": "16.6-fast-generic-rule-proof",
  "profile": "avy",
  "mapping_rows": 373,
  "selected_resolved_columns": 13,
  "original_final_columns": 369,
  "fixed_final_columns": 369,
  "original_v15_class_counts": {
    "IN_BOTH_NO_REVIEW": 360,
    "REVIEW_REQUIRED": 13
  },
  "fixed_v15_class_counts": {
    "IN_BOTH_NO_REVIEW": 360,
    "REVIEW_REQUIRED": 13
  },
  "xml_column_delta_counts_selected": {
    "UNCHANGED": 1,
    "CHANGED": 8,
    "NO_RESOLVED_LINEAGE": 4
  },
  "sql_block_delta_counts": {
    "UNCHANGED": 26,
    "CHANGED": 9
  },
  "delta_status_counts_v16_6": {
    "UNCHANGED": 360,
    "STILL_OPEN": 5,
    "FIX_CANDIDATE_UPSTREAM_CHANGED": 3,
    "FIXED_BY_RESOLVED_RULE_PROOF": 5
  },
  "fixed_by_resolved_rule_proof_v16_6": [
    "DB_CARD_ORIG_CCY_CD",
    "DB_CARD_TXN_DT",
    "SDIRA_TXN_TP",
    "SDIRA_TXN_TP_CD",
    "SDIRA_TXN_YR"
  ],
  "fix_candidate_upstream_changed_v16_6": [
    "BKR_AR_ID",
    "LGCY_TRD_CPCTY_TP_DIM_ID",
    "MM_ALT_ID"
  ],
  "still_open_v16_6": [
    "BATCH_DT",
    "SHRT_SALE_EXMPT_CD",
    "SHRT_SALE_EXMPT_NM",
    "STEP_IN_OUT_IND_CD",
    "STEP_IN_OUT_IND_NM"
  ],
  "new_regression_v16_6": []
}
```
