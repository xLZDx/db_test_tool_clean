# AVY Run Summary — v5.4

- Version: `5.4-sdira-type-code-fix`
- Profile: `avy`
- Target table: `AVY_FACT`
- Mapping rows: `373`
- Join rows: `119`
- Validation error counts: `{}`
- Forbidden ODI final helper present: `False`

## DRD/ODI review fields

- BATCH_DT
- BKR_AR_ID
- DB_CARD_ORIG_CCY_CD
- DB_CARD_TXN_DT
- LGCY_TRD_CPCTY_TP_DIM_ID
- MM_ALT_ID
- SDIRA_TXN_TP
- SDIRA_TXN_TP_CD
- SDIRA_TXN_YR
- SHRT_SALE_EXMPT_CD
- SHRT_SALE_EXMPT_NM
- STEP_IN_OUT_IND_CD
- STEP_IN_OUT_IND_NM

## Note

v5.4: generated SQL is DRD-driven. SDIRA_TXN_TP_CD is parsed directly from TXN.TRD_NUM; SDIRA_TXN_TP is resolved through CL_VAL_CODE. Cancellation flag is strict DRD. ODI XML is evidence only and is not emitted into the SQL body.
