# Universal Insert Builder v5.6 — DRD Source + Executable Comment Gate Fix

## What changed vs v4.9

- AVY run no longer depends on slow workbook-wide autodetection; `--profile avy` uses the stable Table-View layout automatically when explicit overrides are not provided.
- Generated SQL no longer emits ODI helper SQL/comments into the SQL body. ODI evidence remains in `implementation_map.csv`.
- Canonicalizes DRD prose aliases (`b`, `atd`, `orig`, etc.) to generated source aliases (`ACATS_BROKER`, `ACG_TP_DIM`, `CCY`, etc.).
- Reuses reliable global joins, so fields sourced from the same real alias do not create repeated fake TODO joins.
- Fixes AVY audit/session rows where source columns contain audit/default text instead of real table metadata.
- Keeps DRD/ODI mismatch fields as review differences instead of restoring ODI final CTE values.

## AVY usage

```bat
python universal_insert_builder.py ^
  --xlsx "DRD_Activity_Fact(2).xlsx" ^
  --xml "1_SCEN_LH_AVY_PKG_LOAD_AVY_FACT_SIDE_V1_RT_ST_Version_001(2).xml" ^
  --target-schema TRANSACTIONS_OWNER ^
  --target-table AVY_FACT ^
  --profile avy ^
  --out out_avy_v48 ^
  --quiet
```

Manual AVY overrides are still accepted:

```bat
--mapping-sheet "Table-View" --target-col B --source-cols Y,Z,AA --rule-col AD --header-row 12
```

## Output files

| File | Purpose |
|---|---|
| `generated_insert_select_candidate.sql` | DRD-driven SQL blueprint. No `O.`, no `odi_final_source`, no Step5 fake source. |
| `implementation_map.csv` | Per-column generated expression, DRD rule/source, and ODI evidence. |
| `join_inventory.csv` | All joins detected/inferred from DRD rules. |
| `validation_errors.csv` | Remaining blockers. TODO_ON rows mean DRD did not provide enough ON/source-id detail. |
| `tri_compare_report.csv` | DRD vs ODI vs generated classification. |
| `review_required_13_fields.csv` | Filtered AVY review mismatches. |
| `AVY_RUN_SUMMARY.md` | Human-readable result summary. |

## Pass conditions

Generated AVY SQL must satisfy:

- no `odi_final_source`;
- no `FROM odi_final_source O`;
- no `O.` final helper alias;
- no `AVY_FACT_STEP5_STG_RT`;
- no `SSDS_AVY_FACT_STEP5_STG`;
- primary source is `FROM CCAL_REPL_OWNER.TXN TXN`;
- remaining TODO joins are explicit validation blockers, not hidden assumptions.

## Current AVY v4.8 result on uploaded files

- 373 DRD target columns generated.
- 139 DRD join rows generated.
- 13 DRD/ODI mismatches preserved as `REVIEW_REQUIRED`.
- 29 remaining `JOIN_REQUIRES_REVIEW` blockers, all visible in `validation_errors.csv`.
- 0 forbidden ODI-final helper references in generated SQL.


## v5.1 AVY CL_VAL fix

For AVY rows where DRD source table is `CCAL_REPL_OWNER.CL_VAL` and the rule says to check `CL_VAL` by `CL_SCM_ID`, the builder now compiles that source contract directly instead of flagging a missing `CL_VAL_ID` TODO.

Affected AVY rows:

- `STEP_IN_OUT_IND_CD` / `STEP_IN_OUT_IND_NM`: `STEP_IN_OUT_CL_VAL.CL_SCM_ID = 114`
- `SHRT_SALE_EXMPT_CD`: `SHRT_SALE_EXMPT_CD_CL_VAL.CL_SCM_ID = 114`
- `SHRT_SALE_EXMPT_NM`: `SHRT_SALE_EXMPT_NM_CL_VAL.CL_SCM_ID = 115`

Aliases are unique per logical branch, so the short-sale code/name joins do not collide.


## v5.3 strict DRD cancel flag fix

`TRD_CNCLD_F` now follows the DRD wording strictly: it returns `Y` only when a qualifying `CCAL_REPL_OWNER.TXN_RLTNP` cancel pair exists (`TXN_RLTNP_TP_ID = 69`, `TRGT_TXN_ID <> SRC_TXN_ID`, and current `TXN.TXN_ID` appears as either target or source). Otherwise the CASE has no ELSE and returns NULL; the tool does not invent `N`.


## v5.3 note

Fixes AVY SDIRA Transaction Type fields: SDIRA_TXN_TP_CD/SDIRA_TXN_TP now project CL_VAL_CODE/CL_VAL_NM from the DRD CL_VAL lookup keyed by parsed TRADE_NUMBER, and the erroneous CL_VAL_ID = TXN.SRC_STM_ID join is suppressed.


## v5.4 SDIRA type code fix

`SDIRA_TXN_TP_CD` is now compiled directly from the parsed trade number:

```sql
CASE WHEN TXN.SRC_STM_ID = 60 THEN SUBSTR(TXN.TRD_NUM, 1, 3) END
```

The parsed value is then used as the key for the shared `SDIRA_TXN_TP_CL_VAL` lookup:

```sql
SDIRA_TXN_TP_CL_VAL.CL_VAL_CODE = SUBSTR(TXN.TRD_NUM, 1, 3)
```

`SDIRA_TXN_TP` projects `SDIRA_TXN_TP_CL_VAL.CL_VAL_NM`. This removes the incorrect behavior where the code field projected `CL_VAL_CODE` instead of the parsed DRD transaction type code.

## v5.5 executable SQL note

Starting in v5.5, the tool writes two SQL variants:

- `generated_insert_select_candidate.sql` — executable-clean SQL for Check SQL / Oracle validation. Comments are stripped so GUI alias checkers do not treat comment text as SQL aliases.
- `generated_insert_select_candidate_annotated.sql` — DRD-review SQL with comments and rule context for human review.

Validation now includes rendered-SQL checks for raw prose in JOINs, unbalanced parentheses, duplicate SQL aliases, and undeclared SQL aliases after comments are stripped.


## v5.6 executable comment gate fix

Fixes the v5.5 residual orphan-comment bug where malformed/nested DRD comment fragments such as `/* /* TBC */ */` could leave a bare `*/` in `generated_insert_select_candidate.sql`.

The executable SQL file is now hard-scrubbed and gated for:

- no `/*` markers;
- no `*/` markers;
- no `--` line comments;
- no raw DRD prose blockers such as `populate`, `derive based`, or `TODO_ON`.

The annotated SQL still preserves DRD review comments separately.
