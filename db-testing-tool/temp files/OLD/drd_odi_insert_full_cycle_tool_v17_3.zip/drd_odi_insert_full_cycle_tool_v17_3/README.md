# DRD / ODI / Generated INSERT full-cycle tool v17.3

v17.3 combines:

- DRD ↔ ODI comparator: v16.6.5 Excel workbook reports
- DRD-based INSERT generator: v6.2 config-driven profile builder
- no-hardcode gate for insert builder checked-in Python/templates
- final workbook tab: `DRD vs ODI vs INSERT`

## One-command flow

```bash
python full_cycle_drd_odi_insert.py ^
  --xlsx "DRD_Activity_Fact(3).xlsx" ^
  --original-xml "odi_file_1.xml" ^
  --fixed-xml "odi_file_2.xml" ^
  --schema-kb "schema_kb_ds_3.json" ^
  --out "out_full_cycle" ^
  --profile avy ^
  --target-schema TRANSACTIONS_OWNER ^
  --target-table AVY_FACT ^
  --mapping-sheet "Table-View" ^
  --target-col B ^
  --source-cols Y,Z,AA ^
  --rule-col AD
```

## Outputs

```text
out_full_cycle/
  odi_compare/
    independent_reports/independent_reports.xlsx
  insert_builder/
    generated_insert_select_candidate.sql
    tri_compare_report.csv
    final_consistency_summary.json
    hardcode_gate_report.json
    .generated_profile_engine/
  final_reports/
    final_full_cycle_report.xlsx
    step1_compare_report.xlsx
    step4_full_cycle_report.xlsx
    full_cycle_summary.json
  full_cycle_run_summary.json
```

## Final workbook tabs

```text
Summary
DRD vs ODI File 1
DRD vs ODI File 2
DRD vs ODI1 vs ODI2
ODI1 vs ODI2 Columns
ODI1 vs ODI2 SQL Blocks
DRD vs ODI vs INSERT
```

## v6.2 config-driven insert builder

Business/profile terms live in:

```text
insert_builder/profiles/lh_ds3_resolution_profile.json
insert_builder/profiles/rule_patterns.json
insert_builder/profiles/column_semantic_rules.json
```

The checked-in Python/template source is guarded by:

```text
insert_builder/hardcode_gate.py
insert_builder/profiles/no_hardcoded_business_tokens.json
```

`hardcode_gate_report.json` is generated in the insert output directory.


## v17.3 report-generation contract

Reports are generated/published twice:

```text
Step 1 complete:
  final_reports/step1_compare_report.xlsx

Step 4 complete:
  final_reports/step4_full_cycle_report.xlsx
  final_reports/final_full_cycle_report.xlsx
```

`step1_compare_report.xlsx` is a standalone DRD/ODI comparison workbook.
`step4_full_cycle_report.xlsx` is the regenerated workbook with the extra `DRD vs ODI vs INSERT` tab.
