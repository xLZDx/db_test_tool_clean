# Universal Insert Builder v6.2 — Config-driven profile

This package removes source-specific business tokens from checked-in executable Python.

Public entrypoint:

```bash
python universal_insert_builder.py --xlsx DRD.xlsx --xml helper.xml --out out_dir --schema-kb schema_kb_ds_3.json
```

Default profile:

```text
profiles/lh_ds3_resolution_profile.json
```

Generated runtime engine:

```text
<out>/.generated_profile_engine/
```

Hardcode gate:

```bash
python hardcode_gate.py --root .
```

The gate scans checked-in `.py` and `.py.tpl` files and fails if configured business/domain tokens appear outside approved config/generated locations.
