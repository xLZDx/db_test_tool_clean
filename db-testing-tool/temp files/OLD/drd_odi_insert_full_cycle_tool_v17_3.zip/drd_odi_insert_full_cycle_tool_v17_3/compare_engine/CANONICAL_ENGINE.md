# v16.6.5 Excel workbook reports

Every successful run creates:

```text
independent_reports/independent_reports.xlsx
independent_reports/summary.json
```

Workbook tabs:

```text
Summary
DRD vs ODI File 1
DRD vs ODI File 2
DRD vs ODI1 vs ODI2
ODI1 vs ODI2 Columns
ODI1 vs ODI2 SQL Blocks
```
