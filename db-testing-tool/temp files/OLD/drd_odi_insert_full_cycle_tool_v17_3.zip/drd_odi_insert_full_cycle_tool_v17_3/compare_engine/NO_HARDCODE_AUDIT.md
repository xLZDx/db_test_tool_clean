# v16.6 No-Hardcode Audit

The v16.6 proof layer removes v16.5 fixture boosters such as column-family/table-specific tokens.

Scope of the audit:
- `reclassify_v16_6_generic_rule_proof.py`
- `compare_drd_odi_v16_6_generic_rule_proof.py`

Expected result:
- No business target/table fixture branches.
- Evidence terms are derived from DRD row values and resolved ODI lineage values.

Note: `compare_drd_odi_universal.py` is the legacy v15 baseline module and still contains known profile/curated logic. It is not the v16.6 proof layer.
