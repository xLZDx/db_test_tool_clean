# Canonical engine decision

Version: v16.6.2

Public entrypoint:

```bash
python compare_drd_odi_v16_6_generic_rule_proof.py ...
```

This entrypoint:
1. Delegates to the canonical fast generic rule-proof engine.
2. Always generates independent reports under `independent_reports/`.

Always-generated independent reports:

```text
independent_reports/01_DRD_vs_ODI_File_1.csv
independent_reports/02_DRD_vs_ODI_File_2.csv
independent_reports/03_ODI1_vs_ODI2_Columns_with_DRD_logic.csv
independent_reports/04_ODI1_vs_ODI2_SQL_Blocks_with_DRD_logic.csv
independent_reports/independent_reports.xlsx
independent_reports/summary.json
```

Canonical engine:

```text
compare_drd_odi_v16_6_fast_generic_rule_proof.py
```
