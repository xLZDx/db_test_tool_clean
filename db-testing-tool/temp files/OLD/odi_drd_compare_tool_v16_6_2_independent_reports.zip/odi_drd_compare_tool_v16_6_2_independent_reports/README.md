# ODI DRD Compare Tool v16.6 — Generic Rule Proof

This version fixes v16.5's hardcoded evidence boosters.

Flow:
1. Run v16 delta-safe baseline.
2. Reclassify `FIX_CANDIDATE_UPSTREAM_CHANGED` to `FIXED_BY_RESOLVED_RULE_PROOF` only if proof checks derived from the DRD row pass for fixed XML and fail for original XML.
3. Produce delta and proof reports.

Usage:

```bash
python compare_drd_odi_v16_6_generic_rule_proof.py ^
  --xlsx "DRD_Activity_Fact(3).xlsx" ^
  --original-xml "original.xml" ^
  --fixed-xml "fixed.xml" ^
  --out "out_v16_6" ^
  --mapping-sheet "Table-View" ^
  --target-table AVY_FACT ^
  --target-col B ^
  --source-cols Y,Z,AA ^
  --rule-col AD
```

Key outputs:
- `summary_v16_6_generic_rule_proof.json`
- `delta_report_v16_6_generic_rule_proof.csv`
- `resolved_rule_proof_checks_v16_6.csv`


## v16.6.1 canonical engine

Use:

```bash
python compare_drd_odi_v16_6_generic_rule_proof.py ^
  --xlsx "DRD.xlsx" ^
  --original-xml "old.xml" ^
  --fixed-xml "new.xml" ^
  --out "out_delta"
```

The public generic entrypoint delegates to the canonical fast generic rule-proof engine.


## v16.6.2 always-generated independent reports

Every successful run now creates:

```text
<out>/independent_reports/
  01_DRD_vs_ODI_File_1.csv
  02_DRD_vs_ODI_File_2.csv
  03_ODI1_vs_ODI2_Columns_with_DRD_logic.csv
  04_ODI1_vs_ODI2_SQL_Blocks_with_DRD_logic.csv
  independent_reports.xlsx
  summary.json
```

Run:

```bash
python compare_drd_odi_v16_6_generic_rule_proof.py ^
  --xlsx "DRD.xlsx" ^
  --original-xml "odi_file_1.xml" ^
  --fixed-xml "odi_file_2.xml" ^
  --out "out_delta"
```
