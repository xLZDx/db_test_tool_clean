# Canonical engine decision

Version: v16.6.1

Canonical public entrypoint:

```bash
python compare_drd_odi_v16_6_generic_rule_proof.py ...
```

This wrapper delegates to:

```text
compare_drd_odi_v16_6_fast_generic_rule_proof.py
```

Why:
- The previous v16.6 package contained two paths with different AVY rule-proof results.
- The fast generic engine is now the single source of truth.

Expected AVY result:
- FIXED_BY_RESOLVED_RULE_PROOF: 5
- FIX_CANDIDATE_UPSTREAM_CHANGED: 3
- STILL_OPEN: 5
- NEW_REGRESSION: 0

TaxLot regression guards remain unchanged:
- Closed TaxLot still open: 5
- Open TaxLot still open: 4
