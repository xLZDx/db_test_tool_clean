#!/usr/bin/env python3
"""
Canonical v16.6.1 entrypoint.

Delegates to compare_drd_odi_v16_6_fast_generic_rule_proof.py.

Reason:
- Older v16.6 package contained two v16.6 paths with different AVY rule-proof results.
- v16.6.1 makes the fast generic rule-proof engine the single source of truth.
"""
from __future__ import annotations

import subprocess
import sys
from pathlib import Path


def main(argv=None) -> int:
    here = Path(__file__).resolve().parent
    canonical = here / "compare_drd_odi_v16_6_fast_generic_rule_proof.py"
    if not canonical.exists():
        print(f"ERROR: canonical engine not found: {canonical}", file=sys.stderr)
        return 2
    cmd = [sys.executable, "-B", str(canonical)] + list(sys.argv[1:] if argv is None else argv)
    return subprocess.call(cmd, cwd=str(here))


if __name__ == "__main__":
    raise SystemExit(main())
