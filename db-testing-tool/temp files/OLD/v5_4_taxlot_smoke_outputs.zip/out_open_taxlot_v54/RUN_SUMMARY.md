# Open TaxLot Run Summary — v5.4

- Version: `5.2-cancel-flag-strict-drd-fix`
- Profile: `taxlot`
- Target table: `OPN_TAX_LOTS_NON_BKR_FACT`
- Mapping rows: `66`
- Join rows: `6`
- Validation error counts: `{}`
- Forbidden ODI final helper present: `False`

## DRD/ODI review fields

- ACG_TP_NM
- MISS_COST_BSS_F
- MISS_IVS_COST_F
- WASH_SALE_TP

## Note

v5.3: generated SQL is DRD-driven. Cancellation flag is strict DRD: set Y only when TXN_RLTNP cancel pair exists; otherwise NULL (no invented N). ODI XML is evidence only and is not emitted into the SQL body.
