# Closed TaxLot Run Summary — v5.4

- Version: `5.2-cancel-flag-strict-drd-fix`
- Profile: `taxlot`
- Target table: `CLS_TAX_LOTS_NON_BKR_FACT`
- Mapping rows: `84`
- Join rows: `10`
- Validation error counts: `{'JOIN_REQUIRES_REVIEW': 3}`
- Forbidden ODI final helper present: `False`

## DRD/ODI review fields

- ACG_TP_NM
- CCAL_PD_ID
- POS_CLS_CD
- SRC_STM_CD
- SRC_STM_NM

## Note

v5.3: generated SQL is DRD-driven. Cancellation flag is strict DRD: set Y only when TXN_RLTNP cancel pair exists; otherwise NULL (no invented N). ODI XML is evidence only and is not emitted into the SQL body.
