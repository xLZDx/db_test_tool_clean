# DRD / ODI / Generated INSERT full-cycle tool v17.6 API-first

v17.6 combines:

- DRD ↔ ODI comparator: v16.6.5
- DRD-based INSERT generator: v6.2 config-driven profile builder
- API-first report generation
- Optional Excel rendering from the native API JSON model
- hardcode gate for insert builder checked-in Python/templates

## Key API-first rule

API reports are built directly from raw compare/insert CSV/JSON outputs.

```text
raw compare outputs + raw insert outputs
  -> native API JSON model
  -> optional Excel rendering
```

`--report-mode api` does **not** build an internal Excel workbook and does **not** parse Excel back to JSON.

## Report modes

```bash
--report-mode api
--report-mode excel
--report-mode both
```

### API mode

```text
final_reports/api/manifest.json
final_reports/api/step1_compare_report.json
final_reports/api/step4_full_cycle_report.json
final_reports/api/step1/tabs/*.json
final_reports/api/step4/tabs/*.json
final_reports/api/openapi_contract.json
```

### Excel mode

```text
final_reports/step1_compare_report.xlsx
final_reports/step4_full_cycle_report.xlsx
final_reports/final_full_cycle_report.xlsx
```

### Both mode

Generates all API and Excel artifacts.

## Business status vs process status

`returncode=0` means artifacts were generated successfully.

It does **not** mean business mismatches are solved.

Use:

```text
full_cycle_run_summary.json -> business_status
final_reports/api/manifest.json -> business_status
final_reports/full_cycle_summary.json -> business_status
```

Possible business status values:

```text
SOLVED_OR_NO_ACTIVE_REVIEW_ROWS
REVIEW_REQUIRED
INSERT_BLOCKER
```

## One-command flow

```bash
python full_cycle_drd_odi_insert.py ^
  --xlsx "DRD_Activity_Fact(3).xlsx" ^
  --original-xml "odi_file_1.xml" ^
  --fixed-xml "odi_file_2.xml" ^
  --schema-kb "schema_kb_ds_3.json" ^
  --out "out_full_cycle" ^
  --profile avy ^
  --target-schema TRANSACTIONS_OWNER ^
  --target-table AVY_FACT ^
  --mapping-sheet "Table-View" ^
  --target-col B ^
  --source-cols Y,Z,AA ^
  --rule-col AD ^
  --report-mode both
```

## Optional API server

```bash
python api_report_server.py ^
  --api-dir out_full_cycle/final_reports/api ^
  --host 127.0.0.1 ^
  --port 8000
```

Endpoints:

```text
/health
/manifest
/step1
/step1/tabs/{tab}
/step4
/step4/tabs/{tab}
/openapi_contract
```
