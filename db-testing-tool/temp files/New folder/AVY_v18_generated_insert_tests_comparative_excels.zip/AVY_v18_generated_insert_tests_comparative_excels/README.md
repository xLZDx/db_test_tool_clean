# AVY v18 Generated INSERT + Validation Tests + Comparative Excels

This package contains the AVY generated INSERT, validation/test scripts, API reports, and comparative Excel workbooks.

## Important status

Process status:

```text
ARTIFACTS_GENERATED
```

Business status:

```json
{
  "status": "REVIEW_REQUIRED",
  "meaning": "process success means artifacts were generated; business_status tells whether review items remain",
  "conclusion_counts": {
    "Generated INSERT matches DRD; ODI File 2 still differs from DRD for this mapping item.": 5,
    "Generated INSERT matches DRD; ODI File 2 has related upstream changes but still requires validation.": 3,
    "DRD, ODI File 2 resolved logic, and generated INSERT are aligned by rule proof.": 5
  }
}
```

`returncode=0` means artifacts were generated. It does **not** mean every ODI-side business issue is solved.

## Contents

```text
01_generated_insert/
  generated_insert_select_candidate.sql
  generated_insert_select_candidate_annotated.sql
  generated_insert_select_candidate_drd_blueprint.sql

02_comparative_excels/
  01_step1_compare_report.xlsx
  02_step4_full_cycle_report.xlsx
  03_final_full_cycle_report.xlsx
  04_raw_compare_independent_reports.xlsx

03_api_reports/
  manifest.json
  step1_compare_report.json
  step4_full_cycle_report.json
  step1/tabs/*.json
  step4/tabs/*.json
  openapi_contract.json

04_validation_tests/
  01_explain_plan_generated_insert.sql
  02_create_control_table_from_generated_select_template.sql
  03_field_compare_config_template.json
  04_target_vs_control_field_compare_template.sql
  test_avy_artifacts.py

05_raw_validation_artifacts/
  implementation_map.csv
  tri_compare_report.csv
  final_consistency_summary.json
  hardcode_gate_report.json
  validation_errors.csv
  schema_kb_validation_errors.csv
  schema_kb_resolution_audit.csv
  compare_*.csv/json
```

## Quick verification

Run artifact-contract tests:

```bash
python -m pytest 04_validation_tests/test_avy_artifacts.py
```

Run Oracle compile smoke test:

```sql
@04_validation_tests/01_explain_plan_generated_insert.sql
```

Create control table template:

```sql
@04_validation_tests/02_create_control_table_from_generated_select_template.sql
```

Field-level target-vs-control comparison requires the approved AVY grain. Fill:

```text
04_validation_tests/03_field_compare_config_template.json
```

then adapt/run:

```text
04_validation_tests/04_target_vs_control_field_compare_template.sql
```

## Validation summary

```json
{
  "case": "AVY",
  "source": "v18.0 reuse-mode run using validated AVY compare and insert outputs",
  "run_out": "/mnt/data/avy_v18_insert_tests_excels_build/v18_avy_reuse_run",
  "generated_insert": "01_generated_insert/generated_insert_select_candidate.sql",
  "excel_reports": [
    "02_comparative_excels/01_step1_compare_report.xlsx",
    "02_comparative_excels/02_step4_full_cycle_report.xlsx",
    "02_comparative_excels/03_final_full_cycle_report.xlsx",
    "02_comparative_excels/04_raw_compare_independent_reports.xlsx"
  ],
  "api_manifest": "03_api_reports/manifest.json",
  "tests": [
    "04_validation_tests/01_explain_plan_generated_insert.sql",
    "04_validation_tests/02_create_control_table_from_generated_select_template.sql",
    "04_validation_tests/03_field_compare_config_template.json",
    "04_validation_tests/04_target_vs_control_field_compare_template.sql",
    "04_validation_tests/test_avy_artifacts.py"
  ],
  "mapping_rows": 373,
  "validation_error_counts": {},
  "schema_kb_validation_error_counts": {},
  "hardcode_gate_status": "PASS",
  "hardcode_gate_findings": 0,
  "tri_compare_generated_vs_drd_counts": {
    "DRD_SOURCE": 373
  },
  "process_status": "ARTIFACTS_GENERATED",
  "business_status": {
    "status": "REVIEW_REQUIRED",
    "meaning": "process success means artifacts were generated; business_status tells whether review items remain",
    "conclusion_counts": {
      "Generated INSERT matches DRD; ODI File 2 still differs from DRD for this mapping item.": 5,
      "Generated INSERT matches DRD; ODI File 2 has related upstream changes but still requires validation.": 3,
      "DRD, ODI File 2 resolved logic, and generated INSERT are aligned by rule proof.": 5
    }
  },
  "full_cycle_conclusion_counts": {
    "Generated INSERT matches DRD; ODI File 2 still differs from DRD for this mapping item.": 5,
    "Generated INSERT matches DRD; ODI File 2 has related upstream changes but still requires validation.": 3,
    "DRD, ODI File 2 resolved logic, and generated INSERT are aligned by rule proof.": 5
  }
}
```
