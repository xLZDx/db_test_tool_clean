# Universal DRD / ODI / Generated INSERT Tool v18.0

v18.0 is the universal Hybrid/API-first version.

It implements the latest review comments:
- API JSON is the canonical report model.
- Excel is optional rendering/export.
- API mode does not create/parse Excel.
- process_status is separate from business_status.
- returncode=0 means artifacts generated, not business solved.
- existing backend/app should remain source of truth.

## Quick start

```bash
python full_cycle_drd_odi_insert.py ^
  --xlsx "DRD.xlsx" ^
  --original-xml "odi_file_1.xml" ^
  --fixed-xml "odi_file_2.xml" ^
  --schema-kb "schema_kb_ds_3.json" ^
  --out "out_full_cycle" ^
  --profile avy ^
  --target-schema TRANSACTIONS_OWNER ^
  --target-table AVY_FACT ^
  --mapping-sheet "Table-View" ^
  --target-col B ^
  --source-cols Y,Z,AA ^
  --rule-col AD ^
  --report-mode both
```

## Report modes

```text
--report-mode api    -> API JSON only
--report-mode excel  -> Excel reports
--report-mode both   -> API JSON + Excel
```

## API mode outputs

```text
out/final_reports/api/manifest.json
out/final_reports/api/step1_compare_report.json
out/final_reports/api/step4_full_cycle_report.json
out/final_reports/api/step1/tabs/*.json
out/final_reports/api/step4/tabs/*.json
out/final_reports/api/openapi_contract.json
```

## Excel mode outputs

```text
out/final_reports/step1_compare_report.xlsx
out/final_reports/step4_full_cycle_report.xlsx
out/final_reports/final_full_cycle_report.xlsx
```

## Process vs business status

```text
process_status = artifact/process result
business_status = mapping/business result
```

Business statuses:

```text
SOLVED_OR_NO_ACTIVE_REVIEW_ROWS
REVIEW_REQUIRED
INSERT_BLOCKER
NOT_EVALUATED
```

Important:

```text
returncode=0 only means artifacts were generated.
Check business_status to know if review/blockers remain.
```

For CI:

```bash
--fail-on-business-status REVIEW_REQUIRED,INSERT_BLOCKER
```

This returns non-zero when those business statuses appear.

## Reuse mode

```bash
python full_cycle_drd_odi_insert.py ^
  --out "out_reuse" ^
  --existing-compare-out "path/to/odi_compare" ^
  --existing-insert-out "path/to/insert_builder" ^
  --report-mode both
```

## API server

```bash
python api_report_server.py ^
  --api-dir out_full_cycle/final_reports/api ^
  --host 127.0.0.1 ^
  --port 8000
```

Endpoints:

```text
/health
/manifest
/step1
/step1/tabs/{tab}
/step4
/step4/tabs/{tab}
/openapi_contract
```

## Backend integration

Use:

```text
backend_integration/service_adapter.py
backend_integration/fastapi_router.py
```

Recommended architecture:

```text
existing backend/app = source of truth
v18.0 universal core = compare/insert/report contract
manifest.json = canonical API/UI response
Excel = optional export
```

## Final Excel tabs in both/excel mode

```text
Summary
DRD vs ODI File 1
DRD vs ODI File 2
DRD vs ODI1 vs ODI2
ODI1 vs ODI2 Columns
ODI1 vs ODI2 SQL Blocks
DRD vs ODI vs INSERT
```
