# Dream Team Review and Plan — v18.0

## Decision
Use Hybrid architecture:
- existing backend/app remains source of truth;
- v18.0 is a universal core and API-first report contract;
- Excel is export-only / optional rendering.

## Architect
Do not run two independent production truth paths. Integrate v18.0 through service_adapter.py or the FastAPI router.

## QA
Returncode=0 means artifacts were generated only. Business state must be read from business_status.

## Risk reviewer
False-green risks are controlled by process_status/business_status and optional --fail-on-business-status.

## Code reviewer
Keep API JSON as canonical report model. Do not parse Excel back into JSON. Keep Excel as export.

## Recommended rollout
1. Run CLI with --report-mode api for regression.
2. Mount backend_integration/service_adapter.py into the existing backend.
3. Make manifest.json the UI/API source.
4. Enable --fail-on-business-status REVIEW_REQUIRED,INSERT_BLOCKER only in CI gates where unresolved business review must fail.
