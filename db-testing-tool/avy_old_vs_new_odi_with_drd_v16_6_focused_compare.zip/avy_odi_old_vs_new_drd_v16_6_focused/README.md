# AVY old ODI vs new ODI with DRD — v16.6 focused comparison

This output is built in the style of `fixed_v15_mismatch_rows.csv`, but applies the v16.6 generic rule-proof delta.

## Summary

```json
{
  "source": "v16.6 AVY original ODI vs new ODI with DRD",
  "rows_like_fixed_v15_mismatch_rows": 14,
  "remaining_rows_after_v16_6": 11,
  "group_status_counts": {
    "STILL_OPEN": 4,
    "FIXED_BY_RESOLVED_RULE_PROOF": 3,
    "FIX_CANDIDATE_UPSTREAM_CHANGED": 3,
    "UNCHANGED_NO_ACTIVE_MISMATCH_BY_V16_6": 1,
    "NON_COLUMN_GROUP_REVIEW": 1,
    "STILL_OPEN_STRUCTURAL_REVIEW": 2
  },
  "column_delta_counts": {
    "UNCHANGED": 360,
    "STILL_OPEN": 5,
    "FIX_CANDIDATE_UPSTREAM_CHANGED": 3,
    "FIXED_BY_RESOLVED_RULE_PROOF": 5
  },
  "fixed_by_rule_proof_columns": [
    "DB_CARD_ORIG_CCY_CD",
    "DB_CARD_TXN_DT",
    "SDIRA_TXN_TP",
    "SDIRA_TXN_TP_CD",
    "SDIRA_TXN_YR"
  ],
  "still_open_columns": [
    "BATCH_DT",
    "SHRT_SALE_EXMPT_CD",
    "SHRT_SALE_EXMPT_NM",
    "STEP_IN_OUT_IND_CD",
    "STEP_IN_OUT_IND_NM"
  ],
  "fix_candidate_columns": [
    "BKR_AR_ID",
    "LGCY_TRD_CPCTY_TP_DIM_ID",
    "MM_ALT_ID"
  ]
}
```

## Files

- `avy_old_odi_vs_new_odi_with_drd_v16_6_mismatch_rows_style.csv` — main grouped table, same concept as `fixed_v15_mismatch_rows`, but includes original ODI, fixed ODI, DRD mapping, v16.6 status and resolved lineage.
- `fixed_v16_6_remaining_mismatch_rows.csv` — only rows that remain open/candidate after v16.6; fixed proof rows are removed.
- `avy_old_vs_new_odi_drd_v16_6_column_level_changed_or_open.csv` — column-level delta for all non-UNCHANGED columns.
- `summary.json` — counts.
