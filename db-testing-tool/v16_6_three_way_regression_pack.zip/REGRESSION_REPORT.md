# v16.6 Three-way regression report

This pack compares every case across:

1. ODI original vs ODI fixed/resolved lineage.
2. DRD vs original ODI classification.
3. DRD vs fixed ODI classification.
4. Delta: fixed / still open / new regression.

## Executive summary

| Case | DRD rows | Original ODI cols | Fixed ODI cols | SQL blocks changed | Fixed by proof | Fix candidates | Still open | New regressions |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| AVY original vs v2 | 373 | 369 | 369 | 9 | 5 | 3 | 5 | 0 |
| Closed TaxLot guard | 84 | 83 | 83 | 0 | 0 | 0 | 5 | 0 |
| Open TaxLot guard | 66 | 66 | 66 | 0 | 0 | 0 | 4 | 0 |

## AVY original vs v2

### Counts

| Metric | Value |
|---|---:|
| DRD rows | 373 |
| Original final ODI columns | 369 |
| Fixed final ODI columns | 369 |
| SQL block delta counts | `{'UNCHANGED': 26, 'CHANGED': 9}` |
| ODI resolved column delta counts | `{'UNCHANGED': 1, 'CHANGED': 8, 'NO_RESOLVED_LINEAGE': 4}` |
| DRD vs original status counts | `{'IN_BOTH_NO_REVIEW': 360, 'REVIEW_REQUIRED': 13}` |
| DRD vs fixed status counts | `{'IN_BOTH_NO_REVIEW': 360, 'REVIEW_REQUIRED': 13}` |
| Delta status counts | `{'UNCHANGED': 360, 'STILL_OPEN': 5, 'FIX_CANDIDATE_UPSTREAM_CHANGED': 3, 'FIXED_BY_RESOLVED_RULE_PROOF': 5}` |

### Fixed by resolved rule proof
- `DB_CARD_ORIG_CCY_CD`
- `DB_CARD_TXN_DT`
- `SDIRA_TXN_TP`
- `SDIRA_TXN_TP_CD`
- `SDIRA_TXN_YR`

### Fix candidates, upstream changed but not auto-promoted
- `BKR_AR_ID`
- `LGCY_TRD_CPCTY_TP_DIM_ID`
- `MM_ALT_ID`

### Still open
- `BATCH_DT`
- `SHRT_SALE_EXMPT_CD`
- `SHRT_SALE_EXMPT_NM`
- `STEP_IN_OUT_IND_CD`
- `STEP_IN_OUT_IND_NM`

### New regressions
- none

### Files
- `avy/01_ODI_original_vs_fixed_resolved_lineage_delta.csv`
- `avy/02_ODI_original_vs_fixed_sql_block_delta.csv`
- `avy/03_DRD_vs_original_ODI_classification.csv`
- `avy/04_DRD_vs_fixed_ODI_classification.csv`
- `avy/05_delta_fixed_still_open_new_regression.csv`

## Closed TaxLot guard

### Counts

| Metric | Value |
|---|---:|
| DRD rows | 84 |
| Original final ODI columns | 83 |
| Fixed final ODI columns | 83 |
| SQL block delta counts | `{'UNCHANGED': 7}` |
| ODI resolved column delta counts | `{'UNCHANGED': 4, 'NO_RESOLVED_LINEAGE': 1}` |
| DRD vs original status counts | `{'IN_BOTH_NO_REVIEW': 61, 'REVIEW_REQUIRED': 5, 'MATCH_EQUIVALENT': 18}` |
| DRD vs fixed status counts | `{'IN_BOTH_NO_REVIEW': 61, 'REVIEW_REQUIRED': 5, 'MATCH_EQUIVALENT': 18}` |
| Delta status counts | `{'UNCHANGED': 79, 'STILL_OPEN': 5}` |

### Fixed by resolved rule proof
- none

### Fix candidates, upstream changed but not auto-promoted
- none

### Still open
- `ACG_TP_NM`
- `CCAL_PD_ID`
- `POS_CLS_CD`
- `SRC_STM_CD`
- `SRC_STM_NM`

### New regressions
- none

### Files
- `closed_taxlot/01_ODI_original_vs_fixed_resolved_lineage_delta.csv`
- `closed_taxlot/02_ODI_original_vs_fixed_sql_block_delta.csv`
- `closed_taxlot/03_DRD_vs_original_ODI_classification.csv`
- `closed_taxlot/04_DRD_vs_fixed_ODI_classification.csv`
- `closed_taxlot/05_delta_fixed_still_open_new_regression.csv`

## Open TaxLot guard

### Counts

| Metric | Value |
|---|---:|
| DRD rows | 66 |
| Original final ODI columns | 66 |
| Fixed final ODI columns | 66 |
| SQL block delta counts | `{'UNCHANGED': 4}` |
| ODI resolved column delta counts | `{'UNCHANGED': 4}` |
| DRD vs original status counts | `{'IN_BOTH_NO_REVIEW': 41, 'REVIEW_REQUIRED': 4, 'MATCH_EQUIVALENT': 21}` |
| DRD vs fixed status counts | `{'IN_BOTH_NO_REVIEW': 41, 'REVIEW_REQUIRED': 4, 'MATCH_EQUIVALENT': 21}` |
| Delta status counts | `{'UNCHANGED': 62, 'STILL_OPEN': 4}` |

### Fixed by resolved rule proof
- none

### Fix candidates, upstream changed but not auto-promoted
- none

### Still open
- `ACG_TP_NM`
- `MISS_COST_BSS_F`
- `MISS_IVS_COST_F`
- `WASH_SALE_TP`

### New regressions
- none

### Files
- `open_taxlot/01_ODI_original_vs_fixed_resolved_lineage_delta.csv`
- `open_taxlot/02_ODI_original_vs_fixed_sql_block_delta.csv`
- `open_taxlot/03_DRD_vs_original_ODI_classification.csv`
- `open_taxlot/04_DRD_vs_fixed_ODI_classification.csv`
- `open_taxlot/05_delta_fixed_still_open_new_regression.csv`
